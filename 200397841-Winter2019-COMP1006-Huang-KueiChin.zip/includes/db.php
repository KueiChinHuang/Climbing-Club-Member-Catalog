<?php
// $conn = new PDO('mysql:host=localhost;dbname=comp1006w', 'root', 'root');
$conn = new PDO ('mysql:host=127.0.0.1:52467;dbname=localdb', 'azure', '6#vWHD_$');  
?>